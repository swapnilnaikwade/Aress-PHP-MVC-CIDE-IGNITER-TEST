<html>
    <head>
        <!--Bootstrap CSS-->
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <!--Custom CSS-->
        <link href="assets/css/master.css" rel="stylesheet">
    </head>
    <body>
<!--Footer-->
	<footer class="footer clearfix">
		<div class="container clearfix">
			<div class="copyright">
				<p>&copy; 2019 All rights reserved.</p>
			</div>
		</div>
	</footer>	
	</body>
	</html>