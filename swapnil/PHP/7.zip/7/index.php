<html>
    <head>
        <link rel="icon" href="assets/images/favicon.ico">
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,500,700,900" rel="stylesheet" type="text/css">
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/master.css" rel="stylesheet">
        <link href="assets/css/animate.css" rel="stylesheet">
        <link href="assets/css/font-awesome.css" rel="stylesheet">
    </head>
    <body>
        <div>     
			</div>
				<div class="container-fluid">
					<div class="row home-page">      
				</div>
			</div>
        </div>
        <?php include 'home.php';?>
    </body>
</html>