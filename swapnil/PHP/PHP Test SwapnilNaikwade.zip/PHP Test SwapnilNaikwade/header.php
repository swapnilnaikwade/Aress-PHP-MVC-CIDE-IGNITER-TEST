<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <!--Bootstrap CSS-->
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <!--Custom CSS-->
        <link href="assets/css/master.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="logo">
                <img src="assets/images/logo.png" alt="Logo">
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li ><a href="home.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a  href="<?php echo 'carousel.php'; ?>">Images </a>
                <li>
            </ul>
        </nav>
        <?php
            ?>
    </body>
</html>